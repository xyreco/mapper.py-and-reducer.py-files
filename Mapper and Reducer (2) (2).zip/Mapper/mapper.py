#!/usr/bin/env python

import sys
import csv

reader = csv.reader(sys.stdin)

for row in reader:

    state = row[7]  
    
    # Emit the state with a count of 1
    print(f"{state}\t1")
