#!/usr/bin/env python

import sys

current_state = None
current_count = 0
state = None

for line in sys.stdin:
    state, count = line.strip().split('\t')
    
    # Convert count to an integer
    count = int(count)
    
    # If we have a new state, output the result for the previous state
    if current_state and current_state != state:
        print(f"{current_state}\t{current_count}")
        current_count = 0
    
    # Set the current state and increment its count
    current_state = state
    current_count += count

# Output t
if current_state == state:
    print(f"{current_state}\t{current_count}")
